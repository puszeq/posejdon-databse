// src/firebase.js

// Firebase App (the core Firebase SDK) is always required and must be listed first
import * as firebase from 'firebase/app';
// import firebase from 'firebase';

// Add the Firebase products that you want to use
import 'firebase/firestore';

// TODO: Replace the following with your app's Firebase project configuration
const firebaseConfig = {
  apiKey: "AIzaSyD4w03kJ5gnxLLSI1703qVDP3OsgQ3VRsU",
  authDomain: "poseidon-c9b3b.firebaseapp.com",
  databaseURL: "https://poseidon-c9b3b.firebaseio.com",
  projectId: "poseidon-c9b3b",
  storageBucket: "poseidon-c9b3b.appspot.com",
  messagingSenderId: "1033325037549",
  appId: "1:1033325037549:web:32a21125257a5494f809e4",
  measurementId: "G-W9XL93F2FS"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export const db = firebase.firestore();